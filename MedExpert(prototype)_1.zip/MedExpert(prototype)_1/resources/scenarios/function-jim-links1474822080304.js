(function(window, undefined) {

  var jimLinks = {
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Rectangle_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_3" : [
        "e49c6352-12e7-402c-b21e-a76598afbabc"
      ],
      "Label_4" : [
        "2c45c2a1-0336-43fd-b4a1-7712f3aa6a93"
      ]
    },
    "e49c6352-12e7-402c-b21e-a76598afbabc" : {
      "Label_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_3" : [
        "e49c6352-12e7-402c-b21e-a76598afbabc"
      ],
      "Label_4" : [
        "2c45c2a1-0336-43fd-b4a1-7712f3aa6a93"
      ],
      "Button_1" : [
        "74804a94-63a3-442e-8471-19c8098cc509"
      ],
      "Button_2" : [
        "11055585-85de-4338-90fb-cbb1e5fe2ade"
      ],
      "Button_3" : [
        "86c95955-fa8c-4ad4-9ba9-d9bd769bb5dd"
      ]
    },
    "9c7d3a4b-0bc8-4f9f-a242-5846a245ec6c" : {
      "Label_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_3" : [
        "11055585-85de-4338-90fb-cbb1e5fe2ade"
      ],
      "Label_4" : [
        "2c45c2a1-0336-43fd-b4a1-7712f3aa6a93"
      ]
    },
    "61509c4e-362b-4ee1-bef3-fcd9fe5c3257" : {
      "Label_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_3" : [
        "11055585-85de-4338-90fb-cbb1e5fe2ade"
      ],
      "Label_4" : [
        "2c45c2a1-0336-43fd-b4a1-7712f3aa6a93"
      ],
      "Category_1" : [
        "298ee4e4-0017-4a64-ba4c-3a91d1f3aa3d"
      ]
    },
    "74804a94-63a3-442e-8471-19c8098cc509" : {
      "Label_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_3" : [
        "74804a94-63a3-442e-8471-19c8098cc509"
      ],
      "Button_1" : [
        "96bf1caf-a492-4434-83a8-5eba13e41d7a"
      ],
      "Button_2" : [
        "9c7d3a4b-0bc8-4f9f-a242-5846a245ec6c"
      ]
    },
    "80c3cedb-4e48-4602-bd61-96aa60736d9b" : {
    },
    "86c95955-fa8c-4ad4-9ba9-d9bd769bb5dd" : {
      "Label_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_3" : [
        "86c95955-fa8c-4ad4-9ba9-d9bd769bb5dd"
      ],
      "Label_4" : [
        "2c45c2a1-0336-43fd-b4a1-7712f3aa6a93"
      ]
    },
    "04104089-3d8a-4c3f-85bf-d0484d150861" : {
      "Label_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_3" : [
        "11055585-85de-4338-90fb-cbb1e5fe2ade"
      ],
      "Label_4" : [
        "2c45c2a1-0336-43fd-b4a1-7712f3aa6a93"
      ],
      "Category_1" : [
        "17d28d4e-e2e1-484c-85a6-738b33dcf081"
      ]
    },
    "a44e9ed5-10aa-4941-9e1b-dda301ad817a" : {
      "Label_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_3" : [
        "11055585-85de-4338-90fb-cbb1e5fe2ade"
      ],
      "Label_4" : [
        "2c45c2a1-0336-43fd-b4a1-7712f3aa6a93"
      ],
      "Paragraph_2" : [
        "0c63c8d5-a475-472e-aea3-1a62bdde3a08"
      ],
      "Input_4" : [
        "0c63c8d5-a475-472e-aea3-1a62bdde3a08"
      ],
      "Input_12" : [
        "298ee4e4-0017-4a64-ba4c-3a91d1f3aa3d"
      ],
      "Input_5" : [
        "a44e9ed5-10aa-4941-9e1b-dda301ad817a"
      ]
    },
    "0c63c8d5-a475-472e-aea3-1a62bdde3a08" : {
      "Label_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_3" : [
        "11055585-85de-4338-90fb-cbb1e5fe2ade"
      ],
      "Label_4" : [
        "2c45c2a1-0336-43fd-b4a1-7712f3aa6a93"
      ],
      "Input_4" : [
        "0c63c8d5-a475-472e-aea3-1a62bdde3a08"
      ],
      "Input_12" : [
        "298ee4e4-0017-4a64-ba4c-3a91d1f3aa3d"
      ],
      "Input_5" : [
        "a44e9ed5-10aa-4941-9e1b-dda301ad817a"
      ]
    },
    "2c45c2a1-0336-43fd-b4a1-7712f3aa6a93" : {
      "Label_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_3" : [
        "e49c6352-12e7-402c-b21e-a76598afbabc"
      ],
      "Label_4" : [
        "2c45c2a1-0336-43fd-b4a1-7712f3aa6a93"
      ]
    },
    "237d2074-94c7-47c6-a764-4c01c53072c5" : {
    },
    "701549f2-62bb-47b1-947c-17761bd33c6f" : {
      "Label_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_3" : [
        "11055585-85de-4338-90fb-cbb1e5fe2ade"
      ],
      "Label_4" : [
        "2c45c2a1-0336-43fd-b4a1-7712f3aa6a93"
      ]
    },
    "11055585-85de-4338-90fb-cbb1e5fe2ade" : {
      "Label_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_3" : [
        "11055585-85de-4338-90fb-cbb1e5fe2ade"
      ],
      "Label_4" : [
        "2c45c2a1-0336-43fd-b4a1-7712f3aa6a93"
      ],
      "Button_1" : [
        "61509c4e-362b-4ee1-bef3-fcd9fe5c3257"
      ],
      "Button_2" : [
        "04104089-3d8a-4c3f-85bf-d0484d150861"
      ]
    },
    "17d28d4e-e2e1-484c-85a6-738b33dcf081" : {
      "Label_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_3" : [
        "11055585-85de-4338-90fb-cbb1e5fe2ade"
      ],
      "Label_4" : [
        "2c45c2a1-0336-43fd-b4a1-7712f3aa6a93"
      ],
      "Category_2" : [
        "701549f2-62bb-47b1-947c-17761bd33c6f"
      ]
    },
    "96bf1caf-a492-4434-83a8-5eba13e41d7a" : {
      "Label_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_3" : [
        "11055585-85de-4338-90fb-cbb1e5fe2ade"
      ]
    },
    "298ee4e4-0017-4a64-ba4c-3a91d1f3aa3d" : {
      "Label_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Label_3" : [
        "11055585-85de-4338-90fb-cbb1e5fe2ade"
      ],
      "Label_4" : [
        "2c45c2a1-0336-43fd-b4a1-7712f3aa6a93"
      ],
      "Input_4" : [
        "0c63c8d5-a475-472e-aea3-1a62bdde3a08"
      ],
      "Input_12" : [
        "298ee4e4-0017-4a64-ba4c-3a91d1f3aa3d"
      ],
      "Input_5" : [
        "0c63c8d5-a475-472e-aea3-1a62bdde3a08"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);